
package librarymodel;

interface IBorrowable {
    void borrowItem(String memberName);
    String returnItem();
}